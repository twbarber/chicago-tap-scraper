from TapScraper.taps.corridor import get_menu
from TapScraper.taps.dryhop import get_menu